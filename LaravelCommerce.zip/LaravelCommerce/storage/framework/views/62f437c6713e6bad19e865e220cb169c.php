<?php $__env->startSection('title', 'Message'); ?>
<?php $__env->startSection('body'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="alert alert-success" role="alert">
                <p class="text-center"><?php echo e($message); ?></p>
                <div class="text-center">
                    <a href="<?php echo e($contactListRoute); ?>" class="btn btn-success mr-2">See Contact List</a>
                    <a href="<?php echo e($formRoute); ?>" class="btn btn-primary">Go Back to Form</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelCommerce\resources\views/success_message.blade.php ENDPATH**/ ?>